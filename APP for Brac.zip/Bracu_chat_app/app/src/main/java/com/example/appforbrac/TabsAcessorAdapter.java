package com.example.appforbrac;

public class TabsAcessorAdapter {
}
